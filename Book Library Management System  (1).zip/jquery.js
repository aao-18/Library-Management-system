// ============================================================
//  jquery.js  –  jQuery
//  Handles: search functionality, live input filtering,
//           Enter key on search, nav hover effects,
//           animated toast (fadeIn / fadeOut)
// ============================================================

$(function () {

  // ── Search button click ────────────────────────────────────
  $('#search-btn').on('click', function () {
    performSearch();
  });

  // ── Search on Enter key ────────────────────────────────────
  $('#search-input').on('keyup', function (e) {
    if (e.key === 'Enter') {
      performSearch();
    }
  });

  // ── Live filtering as user types ───────────────────────────
  $('#search-input').on('input', function () {
    var query = $(this).val().trim();
    // Only auto-filter when there is text; clear results if empty
    if (query.length > 0) {
      performSearch();
    } else {
      $('#search-tbody').empty();
      $('#no-search-results').hide();
      $('#search-table').show();
    }
  });

  // ── Core search function ───────────────────────────────────
  function performSearch() {
    var query   = $('#search-input').val().trim().toLowerCase();
    var results = [];

    // Filter books array (defined in script.js)
    $.each(books, function (index, book) {
      if (book.title.toLowerCase().indexOf(query) !== -1) {
        results.push(book);
      }
    });

    renderSearchResults(results);
  }

  // ── Render search results into the table ───────────────────
  function renderSearchResults(results) {
    var $tbody = $('#search-tbody');
    $tbody.empty();

    if (results.length === 0) {
      $('#no-search-results').show();
      $('#search-table').hide();
    } else {
      $('#no-search-results').hide();
      $('#search-table').show();

      $.each(results, function (i, b) {
        var $tr = $('<tr></tr>');
        $tr.append($('<td></td>').text(b.id));
        $tr.append($('<td></td>').text(b.title));
        $tr.append($('<td></td>').text(b.author));
        $tr.append($('<td></td>').text(b.category));
        $tbody.append($tr);
      });
    }
  }

  // ── Override showToast to use jQuery fadeIn / fadeOut ──────
  // This replaces the plain JS version defined in script.js
  window.showToast = function (msg) {
    var $toast = $('#toast');
    $toast.text(msg).fadeIn(300);
    setTimeout(function () {
      $toast.fadeOut(600);
    }, 3000);
  };

  // ── Highlight table rows on hover using jQuery ─────────────
  // (Supplements the CSS :hover rule as shown in the notes)
  $(document).on('mouseenter', '#books-tbody tr', function () {
    $(this).css('background-color', '#fdf6e3');
  }).on('mouseleave', '#books-tbody tr', function () {
    $(this).css('background-color', '');
  });

  // ── Close edit modal when clicking the backdrop ────────────
  $('#edit-modal').on('click', function (e) {
    if ($(e.target).is('#edit-modal')) {
      closeEditModal();
    }
  });

  // ── Animate form fields with a brief highlight on focus ────
  $(document).on('focus', 'input, select', function () {
    $(this).stop(true).animate({ opacity: 1 }, 150);
  });

});
