// ============================================================
//  script.js  –  Plain JavaScript
//  Handles: data store, tab navigation, registration,
//           validation, table rendering, delete, edit modal
// ============================================================

// ── Data store ──────────────────────────────────────────────
var books = [];

// ── Tab navigation ───────────────────────────────────────────
function showSection(id, link) {
  // Hide all sections
  var sections = document.querySelectorAll('section');
  for (var i = 0; i < sections.length; i++) {
    sections[i].classList.remove('active');
  }

  // Remove active from all nav links
  var navLinks = document.querySelectorAll('nav a');
  for (var j = 0; j < navLinks.length; j++) {
    navLinks[j].classList.remove('active');
  }

  // Show the target section
  var targetId = (id === 'search') ? 'search-section' : id;
  document.getElementById(targetId).classList.add('active');
  link.classList.add('active');

  // Refresh display table when switching to it
  if (id === 'display') {
    renderTable();
  }

  // Reset search tab when opening it
  if (id === 'search') {
    document.getElementById('search-input').value = '';
    document.getElementById('search-tbody').innerHTML = '';
    document.getElementById('no-search-results').style.display = 'none';
    document.getElementById('search-table').style.display = 'table';
  }

  return false;
}

// ── Register Book ────────────────────────────────────────────
function registerBook() {
  var id       = document.getElementById('book-id').value.trim();
  var title    = document.getElementById('book-title').value.trim();
  var author   = document.getElementById('book-author').value.trim();
  var category = document.getElementById('book-category').value;

  // Hide all error messages first
  hideErrors(['err-id', 'err-title', 'err-author', 'err-category']);

  var valid = true;

  // Validate Book ID
  if (!id) {
    document.getElementById('err-id').textContent = 'Book ID is required.';
    showError('err-id');
    valid = false;
  } else if (isDuplicateId(id)) {
    document.getElementById('err-id').textContent =
      'This Book ID already exists. IDs must be unique.';
    showError('err-id');
    valid = false;
  }

  if (!title)    { showError('err-title');    valid = false; }
  if (!author)   { showError('err-author');   valid = false; }
  if (!category) { showError('err-category'); valid = false; }

  if (!valid) return;

  // Add to data store
  books.push({ id: id, title: title, author: author, category: category });

  // Clear form fields
  document.getElementById('book-id').value       = '';
  document.getElementById('book-title').value    = '';
  document.getElementById('book-author').value   = '';
  document.getElementById('book-category').value = '';

  showToast('Book "' + title + '" registered successfully!');
}

// Check if a Book ID already exists
function isDuplicateId(id) {
  for (var i = 0; i < books.length; i++) {
    if (books[i].id.toLowerCase() === id.toLowerCase()) return true;
  }
  return false;
}

// ── Render Books Table ───────────────────────────────────────
function renderTable() {
  var tbody    = document.getElementById('books-tbody');
  var noBooksMsg = document.getElementById('no-books');

  tbody.innerHTML = '';

  if (books.length === 0) {
    noBooksMsg.style.display = 'block';
    document.getElementById('books-table').style.display = 'none';
    return;
  }

  noBooksMsg.style.display = 'none';
  document.getElementById('books-table').style.display = 'table';

  for (var i = 0; i < books.length; i++) {
    var b  = books[i];
    var tr = document.createElement('tr');

    tr.innerHTML =
      '<td>' + escHtml(b.id)       + '</td>' +
      '<td>' + escHtml(b.title)    + '</td>' +
      '<td>' + escHtml(b.author)   + '</td>' +
      '<td>' + escHtml(b.category) + '</td>' +
      '<td>' +
        '<button class="btn btn-edit"   onclick="openEditModal(\'' + escHtml(b.id) + '\')">Edit</button> ' +
        '<button class="btn btn-danger" onclick="deleteBook(\''    + escHtml(b.id) + '\')">Delete</button>' +
      '</td>';

    tbody.appendChild(tr);
  }
}

// ── Delete Book ──────────────────────────────────────────────
function deleteBook(id) {
  if (!confirm('Delete book with ID "' + id + '"?')) return;

  for (var i = 0; i < books.length; i++) {
    if (books[i].id === id) {
      var name = books[i].title;
      books.splice(i, 1);
      renderTable();
      showToast('"' + name + '" has been removed.');
      return;
    }
  }
}

// ── Edit Modal ───────────────────────────────────────────────
function openEditModal(id) {
  for (var i = 0; i < books.length; i++) {
    if (books[i].id === id) {
      document.getElementById('edit-id').value       = books[i].id;
      document.getElementById('edit-title').value    = books[i].title;
      document.getElementById('edit-author').value   = books[i].author;
      document.getElementById('edit-category').value = books[i].category;
      hideErrors(['err-edit-title', 'err-edit-author', 'err-edit-category']);
      document.getElementById('edit-modal').classList.add('open');
      return;
    }
  }
}

function closeEditModal() {
  document.getElementById('edit-modal').classList.remove('open');
}

function saveEdit() {
  var id       = document.getElementById('edit-id').value;
  var title    = document.getElementById('edit-title').value.trim();
  var author   = document.getElementById('edit-author').value.trim();
  var category = document.getElementById('edit-category').value;

  hideErrors(['err-edit-title', 'err-edit-author', 'err-edit-category']);
  var valid = true;

  if (!title)    { showError('err-edit-title');    valid = false; }
  if (!author)   { showError('err-edit-author');   valid = false; }
  if (!category) { showError('err-edit-category'); valid = false; }

  if (!valid) return;

  for (var i = 0; i < books.length; i++) {
    if (books[i].id === id) {
      books[i].title    = title;
      books[i].author   = author;
      books[i].category = category;
      break;
    }
  }

  closeEditModal();
  renderTable();
  showToast('Book "' + title + '" updated successfully!');
}

// ── Toast notification ───────────────────────────────────────
function showToast(msg) {
  var toast = document.getElementById('toast');
  toast.textContent    = msg;
  toast.style.display  = 'block';
  setTimeout(function () {
    toast.style.display = 'none';
  }, 3000);
}

// ── Utility helpers ──────────────────────────────────────────
function showError(id) {
  document.getElementById(id).style.display = 'block';
}

function hideErrors(ids) {
  for (var i = 0; i < ids.length; i++) {
    document.getElementById(ids[i]).style.display = 'none';
  }
}

// Escape HTML to prevent XSS when injecting strings into innerHTML
function escHtml(str) {
  return str
    .replace(/&/g,  '&amp;')
    .replace(/</g,  '&lt;')
    .replace(/>/g,  '&gt;')
    .replace(/"/g,  '&quot;');
}

// Wire up the Register button via plain JS
document.getElementById('register-btn').onclick = registerBook;

// Wire up modal buttons via plain JS
document.getElementById('save-edit-btn').onclick   = saveEdit;
document.getElementById('cancel-edit-btn').onclick = closeEditModal;
